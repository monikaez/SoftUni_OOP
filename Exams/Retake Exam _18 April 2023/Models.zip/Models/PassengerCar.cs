﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDriveRent.Models;

public class PassengerCar : Vehicle
{
    //PassengerCar has a constant value for MaxMileage = 450
    private const double maxMileage = 450;
    public PassengerCar(string brand, string model, string licensePlateNumber) : base(brand, model, maxMileage, licensePlateNumber)
    {
    }
}
