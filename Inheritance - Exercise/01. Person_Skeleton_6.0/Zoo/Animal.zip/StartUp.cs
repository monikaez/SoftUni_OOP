﻿using System.Xml.Linq;

namespace Zoo;

public class StartUp
{
    public static void Main(string[] args)
    {

    }
}
//Follow the diagram and create all of the classes. Each of them, except the Animal class, should inherit from 
//another class. Every class should have:
// A constructor, which accepts one parameter: name.
// Property Name - string.
