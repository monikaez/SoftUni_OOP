﻿namespace Telephony.Core.Interfaces;

public interface IEngine
{
    void Run();

}