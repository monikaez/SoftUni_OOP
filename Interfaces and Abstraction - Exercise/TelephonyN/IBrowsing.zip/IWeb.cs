﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    public interface IWeb
    {
        string Browse(string site);
    }
}
